package com.ccwl.backend.util;

import java.io.IOException;
import java.util.TimerTask;
import java.util.concurrent.CopyOnWriteArraySet;
import javax.websocket.Session;
import com.ccwl.backend.service.CallOrderService;
import com.ccwl.backend.web.WebSocketTest;
import com.ccwl.common.model.ResultJsonObject;
import com.ccwl.common.spring.ApplicationContextHolder;

public class OrderTimeTask extends TimerTask {
	
	private  Session session;
	 private CopyOnWriteArraySet<WebSocketTest> webSocketSet;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		 try {
				CallOrderService callOrderService = ApplicationContextHolder.context
						.getBean(CallOrderService.class);
				if (session.isOpen()) {
					Integer status = 2;
					ResultJsonObject result = callOrderService
							.queryWaitAudtingNum(status);
					if (CommonErrorCode.SUCCESS_REQUEST.getStatus() == result
							.getCode()) {
						// 群发消息
						for (WebSocketTest item : webSocketSet) {
							try {
								item.sendMessage(result.getData().get("orderCount")
										.toString());
							} catch (IOException e) {
								e.printStackTrace();
								continue;
							}
						}
						// session.getBasicRemote().sendText(result.getData().get("orderCount").toString());
					} else {
						 try {
							session.getBasicRemote().sendText("获取失败");
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			
         } catch (Exception e){
             e.printStackTrace();
         }

	}
	public OrderTimeTask(Session session,
			CopyOnWriteArraySet<WebSocketTest> webSocketSet) {
		super();
		this.session = session;
		this.webSocketSet = webSocketSet;
	}

}
