var EnR = function () {
	var _keyObj = null,
		getKey = function () {
			Utils.ajaxRequest({
				url: contextPath + "getKey",
				async: false
			}).done(function (repObj) {
				_keyObj = repObj;
			}).fail(function (fail) {
				throw "_keyObj ajax error...";
			});
		},log = function (txt) {
			//window.console && console.log(txt);
		},
		/**
		 * 模拟跳转
		 * @param url
		 */
		_redirect = function (url, method, params) {
			//创建form
			var $tempForm = $("<form>"), formEleHtml = "";
			$tempForm.attr({
				action: url,
				target: "_blank",
				method: method,
				style: "display:none;"
			});
			//配置form参数
			for (var p in params) {
				formEleHtml += "<input type='hidden' name='" + p + "' value='" + params[p] + "'/>";
			}
			$tempForm.append(formEleHtml);
			//提交表单，跳转
			$tempForm.trigger("submit");
			//销毁form
			$tempForm = null;
		},
		formEvent = function () {
			// var formDtd=$.Deferred();
			log("开始提交......");
			var $form = $(this),
				//加密是否填充
				isFill = !!$form.attr("data-fill");
			if (isFill) {
				$form.find(".encrypt-field").each(function (index, ef) {
					$(ef).val(encryptByRsa($(ef).val()));
				});

				$form.off().submit();
			} else {
				var oldFormObjs = $form.serializeObject(), efs = (function () {
					var arr = [];
					$form.find(".encrypt-field").each(function (ind, ef) {
						arr.push($.trim($(ef).attr("name")));
					});
					return arr;
				}());
				$form.off();
				_redirect($form.attr("action"), $form.attr("method"), encryptByRsa(oldFormObjs, efs));
			}
		},
		encryptByRsa = function (fieldsObj, encryptFields) {
			if (typeof _keyObj !== "undefined" && _keyObj != null && $.isPlainObject(_keyObj) && !$.isEmptyObject(_keyObj)) {
				//传入两个系数，生成公钥
				var publicKey = RSAUtils.getKeyPair(_keyObj.exponent, '', _keyObj.modulus);
				//不是object类型，直接加密返回
				if (!$.isPlainObject(fieldsObj) && !Utils.isEmpty(fieldsObj)) {
					fieldsObj = RSAUtils.encryptedString(publicKey, encodeURI(fieldsObj)); //加密
				} else {
					//多字段加密
					if ($.isPlainObject(fieldsObj)
						&& !$.isEmptyObject(fieldsObj)
						&& $.isArray(encryptFields) &&
						encryptFields.length > 0) {
						$.each(encryptFields, function (_di, dItem) {
							for (var pro in fieldsObj) {
								if (fieldsObj.hasOwnProperty(dItem) && !Utils.isEmpty(fieldsObj[pro]) && pro === dItem) {
									fieldsObj[pro] = RSAUtils.encryptedString(publicKey, encodeURI(fieldsObj[pro])); //加密
								}
							}
						});
					} else {
						//有配置加密需要加密的个别字段，则加密所有字段
						for (var pro in fieldsObj) {
							if (!Utils.isEmpty(fieldsObj[pro])) {
								fieldsObj[pro] = RSAUtils.encryptedString(publicKey, encodeURI(fieldsObj[pro])); //加密
							}
						}
					}
				}
			} else {
				throw "_keyObj error...";
			}
			return fieldsObj;
		}
	return {
		init: function () {
			$("form.encrypt-form").on("submit", function (e) {
				e.preventDefault();
				formEvent.apply(this);
			});
		},
		g: getKey,
		execSubmit: formEvent,
		/**
		 * 使用rsa加密方法
		 * @param  {[type]} fieldsObj 待字段对象      [description]
		 * @param  {[type]} encryptFields 配置需要加密的字段  [description]
		 * @return {[string]}  加密后的字符串  [description]
		 */
		encryptByRsa: encryptByRsa
	}
}();
EnR.g();